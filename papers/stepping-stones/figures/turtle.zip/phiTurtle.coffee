#!/usr/bin/env coffee
###
phiTurtle.coffee — a PhiBase turtle for students.

  coffee phiTurtle.coffee walk.txt        # writes walk.svg, prints coordinate table

The turtle lives on the 36-degree lattice.  Position is held in the
(e0, e72) basis — e0 = (1,0), e72 = (cos 72, sin 72) — so that every
vertex the turtle can reach is an exact pair of PhiBase numbers
(P(n,p), P(n,p)) with P(n,p) = n + p*phi.  No trigonometry, no floats,
no drift: floating point appears ONLY at SVG render time.

Command language (case-insensitive, '#' starts a comment):

  short            step forward one short unit (length 1)        alias: s
  long             step forward one long unit  (length phi)      alias: l
  left  [k]        turn k * 36 degrees counterclockwise (k=1)    alias: +
  right [k]        turn k * 36 degrees clockwise       (k=1)     alias: -
  penup            move without drawing                          alias: u
  pendown          draw while moving (initial state)             alias: d
  repeat n [ ... ] run the bracketed block n times
###

fs   = require 'fs'
path = require 'path'

# ---------------- PhiBase: P(n,p) = n + p*phi, integer n and p --------------

class PhiBase
  constructor: (@n, @p) ->
  add:    (o) -> new PhiBase @n + o.n, @p + o.p
  sub:    (o) -> new PhiBase @n - o.n, @p - o.p
  mul:    (o) -> new PhiBase @n * o.n + @p * o.p, @n * o.p + @p * o.n + @p * o.p
  isZero:     -> @n is 0 and @p is 0
  toFloat:    -> @n + @p * PHI_FLOAT          # render only
  toString:   -> "P(#{@n},#{@p})"

P = (n, p) -> new PhiBase n, p

PHI_FLOAT = (1 + Math.sqrt 5) / 2            # render only
COS72     = (PHI_FLOAT - 1) / 2              # render only
SIN72     = Math.sqrt(1 - COS72 * COS72)     # render only

# ---------------- The 36-degree rotation in the (e0, e72) basis -------------
#
#   R36 = [ phi-1   1-phi ]        det = (phi-1)*phi = 1
#         [ phi-1     1   ]
#
# Exact in Z[phi]; ten applications return to the identity.

PHI_M1 = P -1,  1        # phi - 1
ONE_MP = P  1, -1        # 1 - phi
PHI    = P  0,  1        # phi

rot36 = ([a, b]) ->
  [ PHI_M1.mul(a).add(ONE_MP.mul b), PHI_M1.mul(a).add(b) ]

# Displacement tables: UNIT_DISP[k] is one short step at heading k*36 degrees,
# LONG_DISP[k] is one long step (phi times the short step).

UNIT_DISP = [ [P(1,0), P(0,0)] ]
UNIT_DISP.push rot36 UNIT_DISP[k] for k in [0...9]
LONG_DISP = ([PHI.mul(a), PHI.mul(b)] for [a, b] in UNIT_DISP)

# ---------------- Parser -----------------------------------------------------

tokenize = (text) ->
  lines = (line.replace /#.*$/, '' for line in text.split '\n')
  toks  = lines.join(' ').replace(/\[/g, ' [ ').replace(/\]/g, ' ] ')
  (t.toLowerCase() for t in toks.split(/\s+/) when t.length)

parse = (toks, pos = 0, depth = 0) ->
  prog = []
  while pos < toks.length
    t = toks[pos]; pos++
    switch t
      when ']'
        throw new Error "unmatched ']'" if depth is 0
        return [prog, pos]
      when 'repeat'
        count = parseInt toks[pos]; pos++
        throw new Error "repeat needs a count" if isNaN count
        throw new Error "repeat needs '['"     if toks[pos] isnt '['
        [body, pos] = parse toks, pos + 1, depth + 1
        prog.push {op: 'repeat', count, body}
      when 'left', '+', 'right', '-'
        k = 1
        if toks[pos]? and /^\d+$/.test toks[pos]
          k = parseInt toks[pos]; pos++
        k = -k if t in ['right', '-']
        prog.push {op: 'turn', k}
      when 'short', 's' then prog.push {op: 'step', size: 'short'}
      when 'long',  'l' then prog.push {op: 'step', size: 'long'}
      when 'penup', 'u' then prog.push {op: 'pen', down: false}
      when 'pendown','d' then prog.push {op: 'pen', down: true}
      else throw new Error "unknown command: #{t}"
  throw new Error "missing ']'" if depth > 0
  [prog, pos]

# ---------------- Turtle ------------------------------------------------------

class Turtle
  constructor: ->
    @pos      = [P(0,0), P(0,0)]
    @heading  = 0                 # multiples of 36 degrees, 0..9
    @pen      = true
    @segments = []                # [from, to] pairs of exact points
    @verts    = new Map           # key -> exact point, dedup for labels
    @trace    = []
    @steps    = 0
    @mark @pos

  key: ([a, b]) -> "#{a.n},#{a.p};#{b.n},#{b.p}"

  mark: (pt) -> @verts.set @key(pt), pt if @pen

  run: (prog) -> @exec cmd for cmd in prog

  exec: (cmd) ->
    switch cmd.op
      when 'repeat' then @run cmd.body for [1..cmd.count]
      when 'pen'    then @pen = cmd.down
      when 'turn'   then @heading = ((@heading + cmd.k) % 10 + 10) % 10
      when 'step'
        table = if cmd.size is 'long' then LONG_DISP else UNIT_DISP
        [da, db] = table[@heading]
        next = [@pos[0].add(da), @pos[1].add(db)]
        @segments.push [@pos, next] if @pen
        @mark @pos; @pos = next; @mark @pos
        @steps++
        @trace.push
          step: @steps, size: cmd.size, heading: @heading * 36
          pos: @pos, pen: @pen

# ---------------- SVG render (floats allowed from here down) ------------------

toXY = ([a, b]) ->
  x = a.toFloat() + b.toFloat() * COS72
  y = b.toFloat() * SIN72
  [x, -y]                          # flip y: SVG grows downward

render = (turtle) ->
  pts = (toXY p for p from turtle.verts.values())
  for [from, to] in turtle.segments
    pts.push toXY(from), toXY(to)
  pts.push [0, 0]
  xs = (p[0] for p in pts); ys = (p[1] for p in pts)
  [minX, maxX] = [Math.min(xs...), Math.max(xs...)]
  [minY, maxY] = [Math.min(ys...), Math.max(ys...)]
  pad   = 1.2
  scale = 130
  w = (maxX - minX + 2 * pad) * scale
  h = (maxY - minY + 2 * pad) * scale
  sx = (x) -> (x - minX + pad) * scale
  sy = (y) -> (y - minY + pad) * scale

  svg = []
  svg.push """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 #{w.toFixed 0} #{h.toFixed 0}" font-family="monospace">"""
  svg.push """<rect width="100%" height="100%" fill="white"/>"""

  for [from, to] in turtle.segments
    [x1, y1] = toXY from; [x2, y2] = toXY to
    svg.push """<line x1="#{sx(x1).toFixed 2}" y1="#{sy(y1).toFixed 2}" x2="#{sx(x2).toFixed 2}" y2="#{sy(y2).toFixed 2}" stroke="#1a237e" stroke-width="2.5" stroke-linecap="round"/>"""

  for pt from turtle.verts.values()
    [x, y]  = toXY pt
    [a, b]  = pt
    origin  = a.isZero() and b.isZero()
    svg.push """<circle cx="#{sx(x).toFixed 2}" cy="#{sy(y).toFixed 2}" r="4.5" fill="#{if origin then '#c62828' else '#1a237e'}"/>"""
    svg.push """<text x="#{(sx(x) + 8).toFixed 2}" y="#{(sy(y) - 8).toFixed 2}" font-size="13" fill="#333">(#{a},#{b})</text>"""

  svg.push """<text x="12" y="#{(h - 14).toFixed 0}" font-size="13" fill="#666">basis: e0=(1,0), e72=(cos72&#176;,sin72&#176;) &#8212; coordinates are exact P(n,p) = n + p&#183;&#966;</text>"""
  svg.push "</svg>"
  svg.join '\n'

# ---------------- Main ---------------------------------------------------------

main = ->
  file = process.argv[2]
  unless file
    console.error "usage: coffee phiTurtle.coffee <walkfile.txt>"
    process.exit 1
  [prog] = parse tokenize fs.readFileSync(file, 'utf8')
  turtle = new Turtle
  turtle.run prog

  console.log "step  size   heading  position"
  for t in turtle.trace
    sz = t.size.padEnd 5
    console.log "#{String(t.step).padStart 4}  #{sz}  #{String(t.heading).padStart 4}\u00b0   (#{t.pos[0]}, #{t.pos[1]})#{if t.pen then '' else '   [pen up]'}"

  [a, b] = turtle.pos
  if a.isZero() and b.isZero()
    console.log "\nCLOSED: turtle returned to (P(0,0), P(0,0)) exactly."
  else
    console.log "\nOPEN: turtle rests at (#{a}, #{b})."

  out = path.join path.dirname(file), path.basename(file, path.extname file) + '.svg'
  fs.writeFileSync out, render turtle
  console.log "wrote #{out}"

main()
