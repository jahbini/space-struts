// tilePlaneEngine.js

import { generateCanonicalTriangles } from './geoGenerator.js';
import { loadFaces } from './loadFacesHelper.js';

let triangleQueue = [];
let placedEdges = new Set();
let currentScale = 30;
let symbolToVec = {};
let canonicalTriangles = [];

function encodeEdge(p1, p2) {
  return [p1.toString(), p2.toString()].sort().join('|');
}

export async function resetTiling() {
  triangleQueue = [];
  placedEdges = new Set();
  currentScale = 30;

  symbolToVec = await loadFaces();
  canonicalTriangles = generateCanonicalTriangles();

  const seed = ['#ffz', '#Ffz', '#FFz'].map(id => symbolToVec[id]);
  triangleQueue.push(seed);
  placedEdges.add(encodeEdge(seed[0], seed[1]));
  placedEdges.add(encodeEdge(seed[1], seed[2]));
  placedEdges.add(encodeEdge(seed[2], seed[0]));
}

export function nextTriangle() {
  if (triangleQueue.length === 0) return null;

  const tri = triangleQueue.shift();
  expandTriangle(tri);

  const scale = Math.pow(1.618033988749895, currentScale);
  const triFloat = tri.map(v => {
    const f = v.toFloatArray();
    return [f[0] * scale, f[1] * scale, f[2] * scale];
  });

  return triFloat;
}

function expandTriangle(tri) {
  for (let i = 0; i < 3; i++) {
    const v1 = tri[i];
    const v2 = tri[(i + 1) % 3];
    const edgeKey = encodeEdge(v1, v2);

    if (placedEdges.has(edgeKey)) {
      console.log(`Edge ${edgeKey} already placed, skipping.`);
      continue;
    }

    const newTri = attachCanonicalTriangle(v1, v2);
    if (newTri) {
      triangleQueue.push(newTri);
      console.log(`Added new triangle based on edge ${edgeKey}`);
      newTri.forEach((v, j) => placedEdges.add(encodeEdge(v, newTri[(j + 1) % 3])));
    } else {
      console.log(`No canonical match for edge ${edgeKey}`);
    }
  }
}

function attachCanonicalTriangle(v1, v2) {
  for (const tri of canonicalTriangles) {
    const [t0, t1, t2] = tri.vertices;
    if (symbolMatch(t0, t1, v1, v2)) return resolveTriangle([t0, t1, t2], v1, v2);
    if (symbolMatch(t1, t2, v1, v2)) return resolveTriangle([t1, t2, t0], v1, v2);
    if (symbolMatch(t2, t0, v1, v2)) return resolveTriangle([t2, t0, t1], v1, v2);
  }
  return null;
}

function symbolMatch(a, b, v1, v2) {
  return (a === v1.symbol && b === v2.symbol);
}

function resolveTriangle([a, b, c], v1, v2) {
  const thirdSymbol = c;
  const vNew = symbolToVec[thirdSymbol];
  return [v1, v2, vNew];
}
